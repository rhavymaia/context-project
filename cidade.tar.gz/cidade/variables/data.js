import OpcoesTrTableCidade from '../components/OpcoesTrTableCidade';

export const columns = [
  {
    name: 'Id',
    selector: (row) => row.id,
    sortable: true,
  },
  {
    name: 'Nome',
    selector: (row) => row.nome,
    sortable: true,
  },
  {
    name: 'Estado',
    selector: (row) => row.estado.uf,
    sortable: true,
  },
  {
    name: 'Capital',
    selector: (row) => (row.capital ? 'Sim' : 'Não'),
  },
  {
    name: 'Latitude',
    selector: (row) => row.latitude,
  },
  {
    name: 'Longitude',
    selector: (row) => row.longitude,
  },
  {
    name: 'Fuso Horário',
    selector: (row) => row.fuso_horario,
  },
  {
    name: 'DDD',
    selector: (row) => row.ddd,
  },
  {
    name: 'Opções',
    selector: (row) => <OpcoesTrTableCidade id={row.id}></OpcoesTrTableCidade>,
    sortable: true,
  },
];
