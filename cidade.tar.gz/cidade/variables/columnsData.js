import OpcoesTrTableCidade from '../components/OpcoesTrTableCidade';

export const columnsData = [
  {
    Header: 'Cidade',
    accessor: 'nome',
  },
  {
    Header: 'Estado',
    accessor: 'estado.uf',
  },
  {
    Header: 'Capital',
    accessor: 'capital',
    Cell: ({ cell: { value } }) => {
      return value === true ? 'Sim' : 'Não';
    },
  },
  {
    Header: 'Latitude',
    accessor: 'latitude',
  },
  {
    Header: 'Longitude',
    accessor: 'longitude',
  },
  {
    Header: 'Fuso Horário',
    accessor: 'fuso_horario',
  },
  {
    Header: 'DDD',
    accessor: 'ddd',
  },
  {
    Header: 'Opções',
    accessor: 'id',
    Cell: ({ cell: { value } }) => {
      return value ? (
        <OpcoesTrTableCidade id={value}></OpcoesTrTableCidade>
      ) : (
        '-'
      );
    },
  },
];
