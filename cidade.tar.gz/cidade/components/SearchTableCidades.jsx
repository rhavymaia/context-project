import React, { useEffect, useMemo } from 'react';
import { Flex, Stack, Button, useDisclosure } from '@chakra-ui/react';

import { MdAdd } from 'react-icons/md';
import { useCidade } from '../contexts/CidadeContext';
import AdicionarFormModalCidade from './AdicionarFormModalCidade';
import EditarFormModalCidade from './EditarFormModalCidade';
import RemoverModalCidade from './RemoverModalCidade';
import DataTablePaginationRemote from 'components/table/DataTablePaginationRemote';

import { columns } from '../variables/data';
import AddButton from 'components/button/AddButton';

const SearchTableCidades = () => {
  const { getData, fetchEstados } = useCidade();

  // Inicializar valores.
  useEffect(() => {
    // Estados.
    fetchEstados();
  }, []);

  // Modal com formulário de atualização.
  const adicionarModal = useDisclosure();

  const handleClickAdicionar = (event) => {
    adicionarModal.onOpen();
  };

  return (
    <>
      {/* Busca */}
      <Flex>
        <Stack className="mx-4 mt-4" direction="row" spacing={4}>
          <AddButton handleClick={handleClickAdicionar} />

          <AdicionarFormModalCidade adicionarModal={adicionarModal} />
        </Stack>
      </Flex>
      {/* table */}
      <div className="mt-3 h-full w-full overflow-x-scroll xl:overflow-hidden">
        <DataTablePaginationRemote
          title={'Cidades'}
          columns={columns}
          getData={getData}
        />
      </div>

      {/* Editar */}
      <EditarFormModalCidade />

      {/* Remover */}
      <RemoverModalCidade />
    </>
  );
};

export default SearchTableCidades;
