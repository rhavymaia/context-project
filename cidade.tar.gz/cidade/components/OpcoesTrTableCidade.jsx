import { Button, Tooltip, Wrap, WrapItem } from '@chakra-ui/react';
import { MdDelete, MdEdit } from 'react-icons/md';
import { useCidade } from '../contexts/CidadeContext';
import DeleteButton from 'components/button/DeleteButton';
import EditButton from 'components/button/EditButton';

const OpcoesTrTableCidade = ({ id }) => {
  const { handleLoadUpdateCidadeForm, handleLoadDeleteCidadeModal } =
    useCidade();

  const handleClickEditar = (event) => {
    handleLoadUpdateCidadeForm(id);
  };

  const handleClickRemover = (event) => {
    handleLoadDeleteCidadeModal(id);
  };

  return (
    <Wrap spacing={2}>
      <WrapItem>
        <DeleteButton handleClick={handleClickRemover} />
      </WrapItem>
      <WrapItem>
        <EditButton handleClick={handleClickEditar} />
      </WrapItem>
    </Wrap>
  );
};

export default OpcoesTrTableCidade;
